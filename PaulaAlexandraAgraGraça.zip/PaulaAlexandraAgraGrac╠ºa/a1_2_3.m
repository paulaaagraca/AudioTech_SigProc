aPR = init_aPR;
[recdata,play] = realtime_gain(3,10)
figure
plot(recdata)